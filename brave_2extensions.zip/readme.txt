extract to:
%localappdata%\BraveSoftware\Brave-Browser\User Data\Default\Extensions
